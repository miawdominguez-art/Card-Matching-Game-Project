import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 * Lead Author(s):
 * @author Mia Dominguez
 * 
 * 
 * 
 * Other contributors:
 *
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * Mr Cressey's Class Videos. “Simple Card Game in Java Swing.” YouTube, 13 Jan. 2021, 
 * www.youtube.com/watch?v=jl_fRf0PIDU.
 *  
 * Version/date: 1.1
 * 
 * 
 */

//class that handles GUI and what you actually see
public class CardMatchingGameView extends JFrame //cardmatching game is a jframe 
{
	
	/**
	 * CardMatchingGameView.java has-a/has-many serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private CardMatchingGame game; //cardmatching game view has a game
	private JLabel status; //cardmatching game view has a status label that shows the score and moves left
	private boolean isUpdating = false; //cardmatching game has a updating time where the player has to wait for the cards to swap back
	
	public CardMatchingGameView(CardMatchingGame game) //default constructor for the game
	{
		this.game = game;
		
		//set up title, size of the gui, the closing operation, and the border/layout
		setTitle("Card Matching Game");
		setSize(800, 450);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		//set status display
		status = new JLabel();
		add(status, BorderLayout.NORTH);
		
		//creates grid for the cards
		int size = (int) Math.sqrt(game.getCards().size());
		JPanel grid = new JPanel(new GridLayout(size, size));
		
		//adds the cards/cardbuttons to the grid/gui
		for (CardButton card : game.getCards())
		{
			grid.add(card);
		
		card.addActionListener(e -> handleClick(card));
		
		}
		
		add(grid, BorderLayout.CENTER);
		
		updateStatus();
		setVisible(true);
	}
	
	private void handleClick(CardButton card)
	{
		if(isUpdating || card.isFaceUp() || card.isMatched())
		{
			return;
		}
		
		card.flip();
		
		if(game.getFirstCardSelected() == null)
		{
			game.setFirstCardSelected(card);
		}
		else
		{
			isUpdating = true;
			game.decreaseMoves();
			
			CardButton first = game.getFirstCardSelected();
			
			if (first.getValue().equals(card.getValue()))
			{
				first.setMatched(true);
				card.setMatched(true);
				game.addScore();
				
				game.clearSelection();
				isUpdating = false;
			}
			else
			{
				Timer timer = new Timer(800, new ActionListener()
				{
					@Override
					public void actionPerformed(ActionEvent e)
					{
						first.flip();
						card.flip();
						game.clearSelection();
						isUpdating = false;
					}

				});
			
				timer.setRepeats(false);
				timer.start();
			}

		}
		
		updateStatus();
		checkGameEnd();
	}
	
	/**
	 * Purpose: check if you ran out of moves
	 */
	private void checkGameEnd()
	{
		// TODO Auto-generated method stub
		if(game.getMovesLeft() <= 0)
		{
			JOptionPane.showMessageDialog(this, "Game Over, Your Score: " + game.getScore());
		}
	}
	/**
	 * Purpose: checks your score and moves left
	 */
	private void updateStatus()
	{
		status.setText("Score: " + game.getScore() + ", Moves Left: " + game.getMovesLeft());
	}

}