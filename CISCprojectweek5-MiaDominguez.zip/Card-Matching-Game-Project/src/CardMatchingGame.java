import java.util.*;

/**
 * Lead Author(s):
 * @author Mia Dominguez
 * 
 * 
 * 
 * Other contributors:
 *
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * Mr Cressey's Class Videos. “Simple Card Game in Java Swing.” YouTube, 13 Jan. 2021, 
 * www.youtube.com/watch?v=jl_fRf0PIDU.
 * 
 *  
 * Version/date: 1.1
 * 
 * 
 */
public class CardMatchingGame
{
	
	private Level level; //CardMatchingGame has a level
	private int score = 0; //cardmatchinggame has a score
	private int movesLeft; //cardmatchinggame has a number of moves left
	private List<CardButton> cards = new ArrayList <>(); //a card matching game has an array of cards
	private CardButton firstCardSelected = null; //a cardmatching game has a first card selected
	
	//create constructor
	public CardMatchingGame(Level level)
	{
		this.level = level;
		this.movesLeft = level.getMaxMoves();
		initializeCards();
	}
	
	/**
	 * Purpose: creates the grid with shuffled cards
	 */
	private void initializeCards()
	{
		// TODO Auto-generated method stub
		int numCards = Level.getNumberOfCards();
		
		List<String> values = new ArrayList<>();
		
		for (int i = 0; i < numCards / 2; i++)
		{
			values.add(String.valueOf(i));
			values.add(String.valueOf(i));
		}
		
		//randomizes where the cards are in the grid
		Collections.shuffle(values);
		
		//creates the card buttons with images
		for (String v: values)
		{
			String frontImage = ("images/" + v + ".png");
			String backImage = ("images/back.png");	
			cards.add(new CardButton(v,frontImage, backImage));
		}
		
		
	}

	//getters and setters
	/**
	 * @return the first selected card
	 */
	public CardButton getFirstCardSelected()
	{
		return firstCardSelected;
	}
	//sets first card selec ted as card read by the button reader
	public void setFirstCardSelected(CardButton card)
	{
		firstCardSelected = card;
	}
	/**
	 * @return clears selected cards
	 */
	public void clearSelection()
	{
		firstCardSelected = null;
	}
	/**
	 * @return the level
	 */
	public Level getLevel()
	{
		return level;
	}
	/**
	 * @return the score
	 */
	public int getScore()
	{
		return score;
	}
	/**
	 * @return the movesLeft
	 */
	public int getMovesLeft()
	{
		return movesLeft;
	}

	//updates moves left
	public void decreaseMoves()
	{
		movesLeft--;
	}
	//updates what your score is
	public void addScore()
	{
		score++;
	}

	/**
	 * Purpose: 
	 * @return
	 */
	public List<CardButton> getCards()
	{
		// TODO Auto-generated method stub
		return cards;
	}

}