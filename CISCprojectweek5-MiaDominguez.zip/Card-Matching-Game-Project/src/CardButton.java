import javax.swing.*;
/**
 * Lead Author(s):
 * @author Mia Dominguez
 * 
 * 
 * 
 * Other contributors:
 *
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * MVC Java Tutorial. (n.d.). Www.youtube.com. https://www.youtube.com/watch?v=dTVVa2gfht8
 * 
 * Gamemaker Game Programming Course. “Java Add Image on JFrame.” YouTube, 2 Oct. 2018, www.youtube.com/watch?v=QiLeau29fOQ.
 * 
 * 
 *  
 * Version/date: 1.1
 * 
 * 
 */
public class CardButton extends JButton
{
	
	/**
	 * CardButton.java has-a/has-many serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private boolean faceUp = false; //a card has a faceup side
	private boolean matched = false; //a card has a matched card
	private String value; //a card has a value
	private ImageIcon frontImage; //a card has a frontimage
	private ImageIcon backImage; //a card has a backimage
	
	public CardButton(String value, String front, String back) //constructor that initializes the button and loads in the images for the front and back sides of the cards
	{
		this.value = value;
		
		frontImage = new ImageIcon(front);
		backImage = new ImageIcon(back);
		
		setIcon(backImage); //tells it to start thje game with the card facing downwards
	}
	
	public void setMatched(boolean matched) //matching constructor
	{
		this.matched = matched;
	}
	
	public void flip() //flips the card
	{
		faceUp =! faceUp;
	}
	
	//getters
	/**
	 * @return the faceUp
	 */
	public boolean isFaceUp()
	{
		return faceUp;
	}
	/**
	 * @return the matched
	 */
	public boolean isMatched()
	{
		return matched;
	}

	/**
	 * @return the value
	 */
	public String getValue()
	{
		return value;
	}
	
	public void updateImage() //updates the image of the card when it gets clkicked and if its matched it will set the icon to the image and if not matched it will turn back over
	{
		if (faceUp || matched)
		{
			setIcon(frontImage); 
		}
		else
		{
			setIcon(backImage);
		}
	}
	

}