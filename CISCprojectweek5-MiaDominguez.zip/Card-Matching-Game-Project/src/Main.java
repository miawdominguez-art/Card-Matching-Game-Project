/**
* Lead Author(s):
* @author Mia Dominguez; 
*
* References:
* Morelli, R., & Walde, R. (2016).
* Java, Java, Java: Object-Oriented Problem Solving
* https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
*
*
* Version: 2026-04-30
*/

/**
 * Purpose: The reponsibility of Main is ...
 *
 * Main is-a ...
 * Main is ...
 */
public class Main
{

	/**
	 * Purpose: 
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Level level = new Level (16,20);
		CardMatchingGame game = new CardMatchingGame(level);
		new CardMatchingGameView(game);
	}

}
