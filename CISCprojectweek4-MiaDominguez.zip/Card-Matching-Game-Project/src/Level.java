/**
 * Lead Author(s):
 * @author Mia Dominguez
 * 
 * 
 * 
 * Other contributors:
 *
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * 
 * 
 *  
 * Version/date: 1.1
 * 
 * 
 */
public class Level
{
	private int numberOfCards; //each level has a number of cards
	private int maxMoves; //each level has a max number of moves allowed
	
	public Level(int numberOfCards, int maxMoves) //default level and moves constructor
	{
		this.numberOfCards = numberOfCards;
		this.maxMoves = maxMoves;
	}

	//getters
	/**
	 * @return the numberOfCards
	 */
	public int getNumberOfCards()
	{
		return numberOfCards;
	}

	/**
	 * @return the maxMoves
	 */
	public int getMaxMoves()
	{
		return maxMoves;
	}

}