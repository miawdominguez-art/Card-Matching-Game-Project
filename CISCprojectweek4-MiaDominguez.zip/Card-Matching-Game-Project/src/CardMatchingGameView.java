
/**
 * Lead Author(s):
 * @author Mia Dominguez
 * 
 * 
 * 
 * Other contributors:
 *
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * 
 * 
 *  
 * Version/date: 1.1
 * 
 * 
 */

public class CardMatchingGameView implements CardButtonListener
{

	@Override
	public void onCardClicked(CardButton cardButton)
	{
		// TODO Auto-generated method stub
		
	}
	
}