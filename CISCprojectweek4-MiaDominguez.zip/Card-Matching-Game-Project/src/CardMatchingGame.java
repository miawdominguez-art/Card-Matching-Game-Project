
/**
 * Lead Author(s):
 * @author Mia Dominguez
 * 
 * 
 * 
 * Other contributors:
 *
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * 
 * 
 *  
 * Version/date: 1.1
 * 
 * 
 */
public class CardMatchingGame 
{
	
	private Level level; //CardMatchingGame has a level
	private int score = 0; //cardmatchinggame has a score
	private int movesLeft; //cardmatchinggame has a number of moves left
	
	//getters
	/**
	 * @return the level
	 */
	public Level getLevel()
	{
		return level;
	}
	/**
	 * @return the score
	 */
	public int getScore()
	{
		return score;
	}
	/**
	 * @return the movesLeft
	 */
	public int getMovesLeft()
	{
		return movesLeft;
	}


}